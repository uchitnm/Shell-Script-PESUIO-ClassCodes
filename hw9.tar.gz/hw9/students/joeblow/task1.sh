#!/bin/bash
# CSE 390, Joe Blow
# This program does lots of great things.

echo "Four score and seven years ago, yo"
echo "some stuff happened that created"
echo "a new nation, conceived in Liberty n stuff,"

# and here are some more lines
echo " and dedicatedto the  preposition  "
echo "thatallmenarecreatedequal,playa."

# all done!
