echo "Now this is the story"
echo "all about how"
echo "my life got flipped turned"
echo "upside down"
echo
echo "I'd like to take a minute"
echo "just sit right there"
echo "I'll tell you how I became the prince"
echo "of a town called Bel Air"

# ^^ # # >_<
